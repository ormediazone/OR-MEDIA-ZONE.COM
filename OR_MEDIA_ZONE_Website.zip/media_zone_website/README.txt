# OR MEDIA ZONE Website

এটি একটি responsive static website template। HTML, CSS এবং JavaScript ব্যবহার করা হয়েছে।

## চালু করার নিয়ম
1. ZIP ফাইলটি Extract করুন।
2. `media_zone_website` ফোল্ডার খুলুন।
3. `index.html` ফাইলে ডাবল-ক্লিক করুন অথবা VS Code-এর Live Server দিয়ে চালু করুন।

## নিজের YouTube ভিডিও যুক্ত করার নিয়ম
`index.html` ফাইলে `data-video="https://www.youtube.com/embed/VIDEO_ID"` খুঁজুন।
`VIDEO_ID`-এর জায়গায় আপনার ভিডিওর ID বসান।

উদাহরণ: YouTube লিংক `https://www.youtube.com/watch?v=AbCd1234` হলে embed URL হবে:
`https://www.youtube.com/embed/AbCd1234`

## নিজের চ্যানেলের লিংক
`index.html` ফাইলে `https://www.youtube.com/` খুঁজে আপনার চ্যানেলের URL বসান।

## ফাইলের তালিকা
- `index.html` — ওয়েবসাইটের কাঠামো ও কনটেন্ট
- `style.css` — ডিজাইন ও responsive layout
- `script.js` — মেনু, সার্চ, ক্যাটাগরি ফিল্টার ও ভিডিও পপআপ
- `assets/media-zone-logo.png` — আপনার দেওয়া লোগো

নোট: এটি frontend website। অনলাইন ভিডিও আপলোড, অ্যাডমিন প্যানেল, লগইন বা ডাটাবেজের জন্য আলাদা backend প্রয়োজন।
