const menuToggle = document.getElementById('menuToggle');
const mainNav = document.getElementById('mainNav');
menuToggle.addEventListener('click', () => {
  const open = mainNav.classList.toggle('open');
  menuToggle.setAttribute('aria-expanded', String(open));
});
mainNav.querySelectorAll('a').forEach(link => link.addEventListener('click', () => {
  mainNav.classList.remove('open');
  menuToggle.setAttribute('aria-expanded', 'false');
}));

const filters = document.querySelectorAll('.filter');
const cards = [...document.querySelectorAll('.video-card')];
const search = document.getElementById('videoSearch');
const emptyState = document.getElementById('emptyState');
let activeFilter = 'all';

function updateVideos() {
  const term = search.value.trim().toLocaleLowerCase();
  let visible = 0;
  cards.forEach(card => {
    const categoryMatch = activeFilter === 'all' || card.dataset.category === activeFilter;
    const textMatch = card.dataset.title.toLocaleLowerCase().includes(term);
    const show = categoryMatch && textMatch;
    card.hidden = !show;
    if (show) visible++;
  });
  emptyState.hidden = visible !== 0;
}
filters.forEach(button => button.addEventListener('click', () => {
  filters.forEach(item => item.classList.remove('active'));
  button.classList.add('active');
  activeFilter = button.dataset.filter;
  updateVideos();
}));
search.addEventListener('input', updateVideos);
document.querySelectorAll('[data-jump]').forEach(link => link.addEventListener('click', () => {
  activeFilter = link.dataset.jump;
  filters.forEach(item => item.classList.toggle('active', item.dataset.filter === activeFilter));
  updateVideos();
}));

const modal = document.getElementById('videoModal');
const playerWrap = document.getElementById('playerWrap');
function closeModal() {
  modal.classList.remove('open');
  modal.setAttribute('aria-hidden', 'true');
  playerWrap.innerHTML = '<div class="player-placeholder"><span>▶</span><p>YouTube ভিডিও লিংক যুক্ত করুন</p><small>নমুনা কার্ডে VIDEO_ID-এর জায়গায় আসল ভিডিও ID বসান।</small></div>';
}
document.querySelectorAll('.thumbnail').forEach(button => button.addEventListener('click', () => {
  const url = button.dataset.video;
  if (url && !url.includes('VIDEO_ID')) {
    playerWrap.innerHTML = `<iframe src="${url}?autoplay=1" title="MEDIA ZONE video" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>`;
  } else {
    playerWrap.innerHTML = '<div class="player-placeholder"><span>▶</span><p>এই ভিডিওর YouTube লিংক এখনো যোগ করা হয়নি</p><small>script.js নয়, index.html ফাইলে সংশ্লিষ্ট কার্ডের VIDEO_ID বদলে দিন।</small></div>';
  }
  modal.classList.add('open');
  modal.setAttribute('aria-hidden', 'false');
}));
document.getElementById('modalClose').addEventListener('click', closeModal);
modal.querySelector('[data-close]').addEventListener('click', closeModal);
document.addEventListener('keydown', event => { if (event.key === 'Escape') closeModal(); });
document.getElementById('year').textContent = new Date().getFullYear();
